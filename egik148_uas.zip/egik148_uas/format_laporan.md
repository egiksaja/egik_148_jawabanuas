# UAS Pengembangan Web – Debug REST API CI4
# nama:Moch Eggy Nuryadi
# nim:231080200148
# Semester: 4 -B2
## Tugas:
- Perbaiki minimal 5 bug dari aplikasi
- Catat bug dan solusinya dalam tabel laporan

### Laporan Bug
| No | File                     | Baris | Bug                        | Solusi                          |
|----|--------------------------|-------|-----------------------------|----------------------------------

| 1  | app/Controllers/AuthController.php | 21        | Tidak ada validasi input saat register   | Tambahkan validasi isset() dan format email |

| 2  | app/Controllers/AuthController.php | 27        | Password tidak di-hash                   | Gunakan `password_hash($data['password'], PASSWORD_DEFAULT)'|

| 3  | app/Controllers/AuthController.php | 32        | Mengembalikan password dalam response    | Jangan tampilkan password, hanya kirim id, name, email|

| 4  | app/Controllers/AuthController.php | 39–40     | Tidak ada validasi input saat login      | Tambahkan pengecekan if (!$email || !$password)|

| 5  | app/Controllers/AuthController.php | 45        | Perbandingan password plain text         | Ganti dengan password_verify($password, $user['password'])|…       

| 6 | app/Libraries/JWTLibrary.php | 6 | Hardcoded secret key | Ambil secret key dari file .env menggunakan getenv('JWT_SECRET') |

| 7 | app/Libraries/JWTLibrary.php | 20 | Tidak ada validasi struktur token | Tambahkan pengecekan jumlah bagian token (count($parts) !== 3) |

## Uji dengan Postman:
- POST /login
- POST /register
- GET /users (token diperlukan)